# Vouch Bot

A vouch bot for keeping track of reputation between users

# 📝 Set-Up
- ```npm i```
- ```node .```

Commands | Usage
------------ | -------------
downvote | downvote <@user | userID> <reason>
ping | ping
reputation | reputation <@user | userID>
vouch | vouch <@user | userID>

# ✨ Contributors
- Coded by Raccoon#7867

# ⚠️ Notes/Warning
Nothing :)

\- [Dark Codes](https://discord.gg/devs)
